function showSettings() {
    const menu = document.querySelector(".stgs-menu");
    menu.style.display = "grid";
}

function closeSettings() {
    const menu = document.querySelector(".stgs-menu");
    menu.style.display = "none";
}